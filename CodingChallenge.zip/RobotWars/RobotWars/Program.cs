﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars
{
    class Program
    {

        private string[] compassPoints = new string[]{"N", "E", "S", "W"};
        private int currentDirection;
        private int robotAx, robotAy;
        private int x, y;
        static void Main(string[] args)
        {
            Program robotProgram = new Program();
        }

        public Program()
        {
            string[] tokens = Console.ReadLine().Split(); 

            x = int.Parse(tokens[0]);
            y = int.Parse(tokens[1]);

            for (int i = 0; i < 2; i++)
            {
                start();
            }

        }
        /**
         * Method will initialise robots location and move the robot around the maze.
         * */
        public void start()
        {
            //read in direction of robot
            string[] tokens1 = Console.ReadLine().Split();
            string robotAd;
            //x y cordinates, ensure it is in maze
            robotAx = int.Parse(tokens1[0]);
            if (robotAx > x)
            {
                robotAx = x;
            }
            else if (robotAx < 0)
            {
                robotAx = 0; ;
            }

            robotAy = int.Parse(tokens1[1]);
            if (robotAy > y)
            {
                robotAy = y;
            }
            else if (robotAy < 0)
            {
                robotAy = 0;
            }
            robotAd = tokens1[2];
            // set direction of robnot
            setCurrentDirection(robotAd);



            char[] input = new char[1000];
            // Read in instructions for user from user
            for (int i = 0; i < input.Length; i++)
            {
                input[i] = Console.ReadKey().KeyChar;
                ConsoleKey ck;
                Enum.TryParse<ConsoleKey>(input[i].ToString(), out ck);

                // space to end move
                if (input[i].ToString() == " ")
                {
                    Console.WriteLine("");
                    break;
                }
                if(input[i].ToString() == "L" || input[i].ToString() == "R")
                {
                    // change direction of robot
                    changeDirection(input[i].ToString());
                }
                else if(input[i].ToString() == "M")
                {
                    // move robot
                    move();
                }
                
            }
            string ax;
            ax = robotAx.ToString() + " " + robotAy.ToString() + " " + compassPoints[currentDirection];
            Console.WriteLine(ax);
            /*Console.Write(robotAx);
            Console.Write(robotAy);
            Console.WriteLine(compassPoints[currentDirection]);*/
        }


        /**
         * method will determing from left or right which position to set for the robot.
         * 
         * */
        public void changeDirection(string direction)
        {
            // If L move direction anti-clockwise
            if (direction == "L")
            {
                int tempPosition = currentDirection - 1;
                if (tempPosition < 0)
                {
                    currentDirection = compassPoints.Length - 1;
                }
                else
                {
                    currentDirection = tempPosition;
                }

            }
            // if R change direction clockwise
            else if (direction == "R")
            {
                int tempPosition = currentDirection + 1;
                if (tempPosition > 3)
                {
                    currentDirection = 0;
                }
                else
                {
                    currentDirection = tempPosition;
                }
            }
        }

        /**
         * method will determine from the current direction whhich coordinates to move to.
         * 
         * */

        public void move()
        {
            string direction = compassPoints[currentDirection];

            switch (direction)
            {
                case "N":
                    // move north
                    moveNorth();
                    break;
                case "E":
                    // move east
                    moveEast();
                    break;
                case "S":
                    //move south
                    moveSouth();
                    break;
                case "W":
                    //move west
                    moveWest();
                    break;
               
            }

        }

        /**
         * change directions for the user to one above. only if possible
         * 
         * */
        public void moveNorth()
        {
            int tempYPoint = robotAy+1;

            if (tempYPoint <= y)
            {
                robotAy = tempYPoint;
            }

        }
        /**
         * change positions for the robot to the right. only if possible.
         * 
         * */
        public void moveWest()
        {
            int tempXPoint = robotAx - 1;

            if (tempXPoint >= 0)
            {
                robotAx = tempXPoint;
            }

        }

        /**
         * move robot to east coordinates.
         * */
        public void moveEast()
        {
            int tempXPoint = robotAx + 1;

            if (tempXPoint <= x)
            {
                robotAx = tempXPoint;
            }

        }
        /**
         * move robot to the south coordinates
         * */
        public void moveSouth()
        {
            int tempYPoint = robotAy - 1;

            if (tempYPoint >= 0)
            {
                robotAy = tempYPoint;
            }

        }

        /**
         * set current direction of the robot
         * 
         * 
         * */
        public void setCurrentDirection(String direction)
        {
            for(int i = 0; i<compassPoints.Length;i++  )
            {
                if(compassPoints[i] == direction)
                {
                    currentDirection = i;
                }
            }
        }
    }
}
