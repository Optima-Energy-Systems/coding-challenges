﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supermarket
{
    class Program
    {


        //prices for items
        private  Dictionary<string, int> prices = new Dictionary<string, int>();
        //data structure containing marker for which discount should be appied
        private Dictionary<string, int> specialPriceMarker = new Dictionary<string, int>();
        //discount price for item
        private Dictionary<string, int> specialPrice = new Dictionary<string, int>();
        //number of items in basket
        private Dictionary<string, int> count = new Dictionary<string, int>();
        private int totalPrice;

        static void Main(string[] args)
        {
            Program pr = new Program();

        }

        public Program()
        {
            //Initialise data structures
            totalPrice = 0;
            prices.Add("A", 50);
            prices.Add("B", 30);
            prices.Add("C", 20);
            prices.Add("D", 15);
            specialPriceMarker.Add("A", 3);
            specialPriceMarker.Add("B", 2);
            specialPrice.Add("A", 130);
            specialPrice.Add("B", 45);

            char[] input = new char[1000];
            for (int i = 0; i < input.Length; i++)
            {
                input[i] = Console.ReadKey().KeyChar;

                addItem( input[i].ToString());
                Console.WriteLine(totalPrice);


            }
        }

        /**
         * mehtod will add item to list, it will also check if the special price marker has 
         * been reached, if it has then the discount will be applied.
         * */
        public void addItem(string item)
        {
            if(prices.ContainsKey(item))
            {
               int  counter = updateCount(item);
                if(specialPriceMarker.TryGetValue(item, out int marker))
                {
                    //if number of item has reached discount amount
                    if(marker == counter)
                    {
                        Console.WriteLine("Special Price");
                        if (specialPrice.TryGetValue(item, out int specialP))
                        {
                            int minusPrice =   (specialPriceMarker[item] - 1) * prices[item];
                            totalPrice = totalPrice - minusPrice;
                            totalPrice = totalPrice + specialPrice[item];
                            //reset discount item counter
                            count[item] = 0;

                        }
                            

                    }
                    else
                    {
                        totalPrice = totalPrice + prices[item];
                    }
                }
                else
                {
                    totalPrice = totalPrice + prices[item];
                }


            }
        }


        /**
         * method to update the count of items int he basket
         * 
         * */
        public int updateCount(string item)
        {
            if (count.ContainsKey(item))
            {
              int counter =  count[item];
                counter = counter + 1;
                count[item] = counter;
                return counter;
            }
            else
            {
                count.Add(item, 1);
                return 1;
            }
        }
    }
}
