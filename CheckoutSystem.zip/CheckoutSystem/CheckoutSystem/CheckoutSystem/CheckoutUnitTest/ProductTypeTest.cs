﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using CheckoutSystem;

namespace CheckoutUnitTest
{
    [TestClass]
    public class ProductTypeTest
    {
        [TestMethod]
        public void TestSpecialOfferUpdate()
        {
            ProductType A = new ProductType("A", 45, new SpecialPrice(2, 15));
            A.DeleteSpecialOffer();
            Assert.IsFalse(A.SpecialOffer.HasValue);
            A.UpdateSpecialOffer(3, 10);
            Assert.IsTrue(A.SpecialOffer.Value.Quantity == 3 && A.SpecialOffer.Value.Price == 10);
        }
    }
}
