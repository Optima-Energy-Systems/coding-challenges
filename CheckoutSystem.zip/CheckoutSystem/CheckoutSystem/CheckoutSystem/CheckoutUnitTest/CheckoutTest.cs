﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using CheckoutSystem;
using System.Collections.Generic;

namespace CheckoutUnitTest
{
    [TestClass]
    public class CheckoutUnitTest
    {
        Dictionary<string, ProductType> availableTypesOfProducts = new Dictionary<string, ProductType>(){
            {"A", new ProductType("A", 50, null) },
            {"B", new ProductType("B", 30, null) },
            {"C", new ProductType("C", 25, new SpecialPrice(2,40)) },
            {"D", new ProductType("D", 35, null) }
        };

        [TestMethod]
        public void testPartialPriceWithoutBargains()
        {
            //for number of elements check if price is correct
            Checkout check = new Checkout(availableTypesOfProducts);
            int result = check.GetPriceOfOneTypeOfProducts("A", 3);
            Assert.AreEqual(result, 150);
        }

        [TestMethod]
        public void testPartialPriceWithBargains()
        {
            //for number of elements check if price is correct
            Checkout check = new Checkout(availableTypesOfProducts);
            int result = check.GetPriceOfOneTypeOfProducts("C", 3);
            Assert.AreEqual(result, 65);
        }

        [TestMethod]
        public void testTotalPrice()
        {
            //for number of elements check if price is correct
            Checkout check = new Checkout(availableTypesOfProducts);
            for(int i=0;i<3;i++) check.Scan("A");
            for (int i = 0; i < 3; i++) check.Scan("C");
            int result = check.GetTotalPrice();
            Assert.AreEqual(result, 215);
        }

        [TestMethod]
        public void testScanOfCorrectItem()
        {
            //for number of elements check if price is correct
            Checkout check = new Checkout(availableTypesOfProducts);
            check.Scan("A");
            Assert.AreEqual(check.CurrentReceipt.Count, 1);
        }

        [TestMethod]
        public void testScanOfIncorrectItem()
        {
            //for number of elements check if price is correct
            Checkout check = new Checkout(availableTypesOfProducts);
            check.Scan("Z");
            Assert.AreEqual(check.CurrentReceipt.Count, 0);
        }

    }
}
