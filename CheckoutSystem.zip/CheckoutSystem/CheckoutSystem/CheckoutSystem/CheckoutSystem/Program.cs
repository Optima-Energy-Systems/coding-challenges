﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckoutSystem
{
    class Program
    {
        static Dictionary<string, ProductType> availableTypesOfProducts = new Dictionary<string, ProductType>(){
                {"A", new ProductType("A", 50, null) },
                {"B", new ProductType("B", 30, null) },
                {"C", new ProductType("C", 25, new SpecialPrice(2,40)) },
                {"D", new ProductType("D", 35, null) }
            };

        static void ShowAvailableProducts()
        {
            foreach (ProductType product in availableTypesOfProducts.Values) Console.WriteLine(product.ToString());
        }


        static void Main(string[] args)
        {
            bool remainFlag = true;
            Checkout check = new Checkout(availableTypesOfProducts);
            do
            {
                Console.WriteLine("Available commands (insert number):");
                Console.WriteLine("0. Exit");
                Console.WriteLine("1. Insert products");
                Console.WriteLine("2. Show available products");
                String response = Console.ReadLine();
                switch (response)
                {
                    case "0": remainFlag = false;break;
                    case "1":
                        Console.WriteLine("Type: \"Exit\" to stop inserting items");
                        bool keepInserting = true;
                        while (keepInserting)
                        {
                            String item = Console.ReadLine();
                            if (item.Equals("Exit")) break;
                            check.Scan(item);
                        }
                        Console.WriteLine("Total price: " + check.GetTotalPrice());
                        break;
                    case "2": ShowAvailableProducts();break;
                    default: Console.WriteLine("wrong command");break;
                }
            } while (remainFlag);
        }
    }
}
