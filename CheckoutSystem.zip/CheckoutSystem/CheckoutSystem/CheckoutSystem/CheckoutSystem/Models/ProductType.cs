﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckoutSystem
{
    public struct SpecialPrice{
        public int Quantity { get; }
        public int Price { get; }

        public SpecialPrice(int quantity, int price)
        {
            Quantity = quantity;
            Price = price;
        }
    }

    public class ProductType : IEquatable<ProductType>
    {
        public string Id { get; set; }
        public int PriceInPence { get; set; }
        public SpecialPrice? SpecialOffer { get; private set; }

        public ProductType(string id,int priceInPence, SpecialPrice? specialOffer)
        {
            this.Id = id;
            this.PriceInPence = priceInPence;
            this.SpecialOffer = specialOffer;
        }

        public bool Equals(ProductType other)
        {
            if (this.Id.Equals(other.Id)) return true;
            return false;
        }

        public void UpdateSpecialOffer(int quantity, int price)
        {
            SpecialOffer = new SpecialPrice(quantity, price);
        }

        public void DeleteSpecialOffer()
        {
            SpecialOffer = null;
        }

        public override string ToString()
        {
            return "Id " + Id + " Price: " + PriceInPence
                    + "; Special offer: " + SpecialOffer?.Price ?? ("NaN" + " for " + SpecialOffer?.Quantity ?? "NaN");
        }

    }
}
