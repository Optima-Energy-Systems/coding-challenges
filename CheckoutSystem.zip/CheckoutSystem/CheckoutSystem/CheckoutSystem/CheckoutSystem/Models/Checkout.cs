﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckoutSystem
{
    public class Checkout : ICheckout
    {
        Dictionary<string,ProductType> AvailableTypesOfProducts { get; set; }

        public List<string> CurrentReceipt { get; private set; }

        public Checkout(Dictionary<string, ProductType> availableTypesOfProducts)
        {
            this.AvailableTypesOfProducts = availableTypesOfProducts;
            CurrentReceipt = new List<string>();
        }

        public void ClearReceipt()
        {
            CurrentReceipt = new List<string>();
        }


        public int GetPriceOfOneTypeOfProducts(string item, int quantity)
        {
            int sum = 0;
            int remainingQ = quantity;
            if (AvailableTypesOfProducts[item].SpecialOffer.HasValue) {
                int times = quantity / AvailableTypesOfProducts[item].SpecialOffer.Value.Quantity;
                sum += AvailableTypesOfProducts[item].SpecialOffer.Value.Price * times;
                remainingQ -= times * AvailableTypesOfProducts[item].SpecialOffer.Value.Quantity;
            }
            sum += remainingQ * AvailableTypesOfProducts[item].PriceInPence;
            return sum;
        }

        public int GetTotalPrice()
        {
            int sum = 0;
            Dictionary<string, int> adder = new Dictionary<string, int>();
            foreach (string item in CurrentReceipt) {
                if (adder.ContainsKey(item)) adder[item]++;
                else adder.Add(item, 1);
            }
            foreach (string item in adder.Keys) sum += GetPriceOfOneTypeOfProducts(item, adder[item]);
            return sum;
        }

        public void Scan(string item)
        {
            item = item.ToUpper();
            if (AvailableTypesOfProducts.ContainsKey(item))
                CurrentReceipt.Add(item);
            else Console.WriteLine("Not recognized item: "+item);
        }

    }
}
