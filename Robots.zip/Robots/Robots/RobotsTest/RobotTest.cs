﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Robots;

namespace RobotsTest
{
    [TestClass]
    public class RobotTest
    {
        [TestMethod]
        public void TestRotationRoutine()
        {
            Robot current = new Robot(0, 0, (CompassDirection)Enum.Parse(typeof(CompassDirection), "N"));
            current.Rotate('L');
            Assert.AreEqual(current.FacedDirection, CompassDirection.W);
            current.Rotate('L');
            Assert.AreEqual(current.FacedDirection, CompassDirection.S);
            current.Rotate('L');
            Assert.AreEqual(current.FacedDirection, CompassDirection.E);
            current.Rotate('L');
            Assert.AreEqual(current.FacedDirection, CompassDirection.N);
            current.Rotate('R');
            Assert.AreEqual(current.FacedDirection, CompassDirection.E);
            current.Rotate('R');
            Assert.AreEqual(current.FacedDirection, CompassDirection.S);
            current.Rotate('R');
            Assert.AreEqual(current.FacedDirection, CompassDirection.W);
            current.Rotate('R');
            Assert.AreEqual(current.FacedDirection, CompassDirection.N);
        }

        [TestMethod]
        public void TestMovingRoutine()
        {

        }

        [TestMethod]
        public void TestPositionUpdatetRoutine()
        {
            Robot current = new Robot(0, 0, (CompassDirection)Enum.Parse(typeof(CompassDirection), "N"));
            current.UpdatePosition(Tuple.Create(1, 0));
            Assert.IsTrue(current.X == 1 && current.Y == 0);
        }

        [TestMethod]
        public void TestCommandExecutiontRoutine()
        {
            Arena arena = new Arena(1, 1);
            Tuple<int, int> movementVector = Tuple.Create(0, 1);
            Robot current = new Robot(0, 0, (CompassDirection)Enum.Parse(typeof(CompassDirection), "N"));

            arena.ProcessCommand('R', ref current);
            Assert.IsTrue(current.FacedDirection.Equals(CompassDirection.E)&&current.X==0 &&current.Y==0);
            arena.ProcessCommand('M', ref current);
            Assert.IsTrue(current.FacedDirection.Equals(CompassDirection.E) && current.X == 1 && current.Y == 0);
            arena.ProcessCommand('L', ref current);
            Assert.IsTrue(current.FacedDirection.Equals(CompassDirection.N) && current.X == 1 && current.Y == 0);
        }

        [TestMethod]
        public void TestMovementVectorGeneratingRoutine()
        {
            Robot current = new Robot(0, 0, (CompassDirection)Enum.Parse(typeof(CompassDirection), "N"));
            Tuple<int, int> result = current.ReturnMovementVector();
            Assert.IsTrue(result.Item1 == 0 && result.Item2 == 1);
        }

        [TestMethod]
        public void TestMovementExecutionRoutine()
        {
            //Dictionary<Tuple<int, int>, Robot> arena = new Dictionary<Tuple<int, int>, Robot>();
            Arena arena = new Arena(1, 1);
            Tuple<int, int> movementVector = Tuple.Create(0, 1);
            Robot current = new Robot(0, 0, (CompassDirection)Enum.Parse(typeof(CompassDirection), "N"));

            arena.PresentAgents.Add(Tuple.Create(0, 0), current);
            arena.MoveAndUpdate(movementVector, ref current);
            Assert.IsTrue(arena.PresentAgents.ContainsKey(Tuple.Create(0,1)));
            Assert.IsFalse(arena.PresentAgents.ContainsKey(Tuple.Create(1, 0)));
            Assert.IsFalse(arena.PresentAgents.ContainsKey(Tuple.Create(0, 0)));
        }
    }
}
