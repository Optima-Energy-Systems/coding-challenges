﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Robots
{
    public class Program
    {
        

        static void Main(string[] args)
        {
            int xSize;
            int ySize;
            Console.WriteLine("Specify location of input file");
            string source = Console.ReadLine();
            using(StreamReader sr = new StreamReader("source")){
                string line = sr.ReadLine();
                string[] tokens = line.Split(' ');
                xSize = Int32.Parse(tokens[0]);
                ySize = Int32.Parse(tokens[1]);
                Arena arena = new Arena(xSize, ySize);
                while (line != null)
                {
                    line = sr.ReadLine();
                    tokens = line.Split(' ');
                    //create robot and insert it
                    Robot current = new Robot(Int32.Parse(tokens[0]), Int32.Parse(tokens[1]), 
                        (CompassDirection)Enum.Parse(typeof(CompassDirection), tokens[2]));                  
                    arena.PresentAgents.Add(Tuple.Create(Int32.Parse(tokens[0]), Int32.Parse(tokens[1])), current);
                    line = sr.ReadLine();
                    foreach(char command in line) {
                        arena.ProcessCommand(command, ref current);
                    }
                    //output
                    Console.WriteLine(current.ToString());
                }
            }
        }
    }
}