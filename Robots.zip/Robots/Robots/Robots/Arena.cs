﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Robots
{
    public class Arena
    {
        public Dictionary<Tuple<int, int>, Robot> PresentAgents  { get;set; }
        public int XSize { get; set; }
        public int YSize { get; set; }

        public Arena(int xSize, int ySize)
        {
            XSize = xSize;
            YSize = ySize;
            PresentAgents = new Dictionary<Tuple<int, int>, Robot>();
        }

        public void ProcessCommand(char command, ref Robot current)
        {
            switch (command)
            {
                case 'M':
                    Tuple<int, int> movementVector = current.ReturnMovementVector();
                    if (current.X + movementVector.Item1 >= 0 && current.X + movementVector.Item1 <= XSize &&
                    current.Y + movementVector.Item2 >=0 && movementVector.Item1 <= YSize)
                    MoveAndUpdate(movementVector, ref current);
                    break;
                case 'R':
                case 'L': current.Rotate(command); break;
                default: break;
            }
        }

        public void MoveAndUpdate(Tuple<int, int> movementVector, ref Robot current)
        {
            PresentAgents.Add(Tuple.Create(current.X + movementVector.Item1, current.Y + movementVector.Item2), current);
            PresentAgents.Remove(Tuple.Create(current.X, current.Y));
            current.UpdatePosition(movementVector);
        }
    }
}
