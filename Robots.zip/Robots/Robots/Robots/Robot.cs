﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Robots
{
    public enum CompassDirection
    {
        N=0,
        E=1,
        S=2,
        W=3
    }

    public class Robot
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public CompassDirection FacedDirection { get; set; }

        public Robot(int x, int y, CompassDirection facedDirection)
        {
            X = x;
            Y = y;
            FacedDirection = facedDirection;
        }

        public void Rotate(char direction)
        {
            if (direction == 'L')
            {
                if ((int)FacedDirection == 0) FacedDirection = (CompassDirection)3;
                else FacedDirection = (CompassDirection)((int)FacedDirection - 1);
            }
            else
            {
                if ((int)FacedDirection == 3) FacedDirection = (CompassDirection)0;
                else FacedDirection = (CompassDirection)((int)FacedDirection + 1);
            }
        }

        public Tuple<int, int> ReturnMovementVector()
        {
            switch (FacedDirection)
            {
                case CompassDirection.N: return Tuple.Create(0, 1);
                case CompassDirection.E: return Tuple.Create(1, 0);
                case CompassDirection.S: return Tuple.Create(0, -1);
                case CompassDirection.W: return Tuple.Create(-1, 0);
            }
            throw new InvalidOperationException();
        }

        public void UpdatePosition(Tuple<int,int> movementVector)
        {
            this.X += movementVector.Item1;
            this.Y += movementVector.Item2;
        }

        public override string ToString()
        {
            return X + ":" + Y + " " + FacedDirection.ToString();
        }
    }
}
